#include "Wad.h"
#include <sstream>
#include <stack>
#include <cstring>


/*
    printNaryTree: recursively prints the content of an N-ary tree in pre-order traversal, 
    where the root node's content is printed first followed by its children's contents. The function 
    also prints information stored in each node's data field.
*/
void printNaryTree(Node* root) {
    if (!root) {
        return;
    }

    std::cout << root->nodeContentnam << " ";

    for (int i = 0; i < root->children.size(); i++) {
        printNaryTree(root->children[i]);
    }

    std::cout << std::endl << "Printing information stored in N-ary tree: " << root->info << std::endl;
}

/*The WAD file format contains information in three sections: the header, which gives basic layout information,
the descriptors, which describe elements in the file, and the lumps, which contain the data themselves. NOTE:
all numbers are in little-Endian format and, where applicable, are designated in bytes!

//File Header
The header contains the file magic (4B), descriptor count(4B), and location (descriptor offset) (4B) of the descriptors in the file:

The magic for a wad file is usually ASCII and always ends in the suffix "WAD" (e.g., "IWAD" or "PWAD").

//Descriptors
The file’s descriptors contain information about elements in the WAD file – its file element offset(4B), length(4B), and name(8B):

Some elements have a length that is zero. These “marker” elements will be interpreted by the daemon as
directories and should be displayed accordingly in the filesystem (see below).

//Lumps
Elements in the WAD format are stored as “lumps” described by the descriptors. These lumps will be
represented in the filesystem by the daemon as individual files that can be opened, read, and closed.

//Marker Elements
There are two primary types of marker elements in WAD files, each of which should be interpreted as
directories by our daemon. The type includes map markers and namespace markers.
Map marker names are of the format "E#M#", where # represents a single decimal digit (e.g., "E1M9").
They are followed by ten (10) map element descriptors. The elements for the next 10 descriptors should be
placed inside of a directory with the map’s name.
Namespace markers come in pairs. A namespace’s beginning is marked with a descriptor whose name has
the suffix "_START" (e.g., "F1_START"), and its ending is marked with a descriptor whose name has the
suffix "_END" (e.g., "F1_END"). Any descriptors for elements falling between the beginning and ending
markers for a namespace should be placed within a directory with the namespace’s name (e.g., "F1").
*/



/*
    The Wad class is used to load and parse files in the WAD format. The loadWad function reads a WAD 
    file from the specified path and extracts information from its header, descriptors, and lumps. It 
    creates a Wad object and populates its fields accordingly. The function also constructs an N-ary 
    tree to represent the directory structure of the WAD file and stores it in the root field of the 
    Wad object. The function returns a pointer to the Wad object. The header, descriptors, and lumps 
    are read using ifstream and bitwise operations to convert little-endian byte arrays to integers.
    // https://www.cyotek.com/blog/reading-doom-wad-files
*/
Wad* Wad::loadWad(const std::string &path){

    std::ifstream infile(path, std::ios::binary);

    char* magic = new char[4];
    char* nameOfElm = new char[8];

    //File Header - magic
    //The header contains the file magic (4B)
    Wad* wad = new Wad();
    infile.read(magic, 4);
    wad->magic = std::string(magic);

    //File Header - descriptor
    //The header contains descriptor count(4B)
    char* charNumberDesc = new char[4];
    infile.read(charNumberDesc, 4);
    int intDescount = int((unsigned char)(charNumberDesc[3]) << 24 | 
                         (unsigned char)(charNumberDesc[2])  << 16 |
                         (unsigned char)(charNumberDesc[1])  << 8 | 
                         (unsigned char)(charNumberDesc[0])); // convert to int
    delete[] charNumberDesc;
    wad->numbDescriptors = intDescount;

    //File Header - location
    //The header contains the location (descriptor offset) (4B)
    char* headerWordDecOffset = new char[4];
    infile.read(headerWordDecOffset, 4);
    int intDescOffset = int((unsigned char)(headerWordDecOffset[3]) << 24 | 
                         (unsigned char)(headerWordDecOffset[2])    << 16 |
                         (unsigned char)(headerWordDecOffset[1])    << 8 | 
                         (unsigned char)(headerWordDecOffset[0])); // convert to int
    delete[] headerWordDecOffset;
    wad->DescriptorOffset = intDescOffset;
    infile.seekg(intDescOffset, std::ios::beg);
    
    Node* root = new Node();
    root->nodeContentnam = "/";
    std::stack<Node*> treeStack;
    treeStack.push(root);

    // prepare for iterations
    int count = 0;
    int descriptorIncrementOffset = 0;

    char* elemOffsetChar = new char[4];
    char* elemLengthChar = new char[4];

    for(int i = 0; i < wad->numbDescriptors; i++){
        
        //Descriptors
        //The file’s descriptors contain information about elements in the WAD file – its file element offset(4B), length(4B), and name(8B):
        infile.read(elemOffsetChar, 4);
        int offsetOfElm = int((unsigned char)(elemOffsetChar[3]) << 24 | 
                              (unsigned char)(elemOffsetChar[2]) << 16 |
                              (unsigned char)(elemOffsetChar[1]) << 8 | 
                              (unsigned char)(elemOffsetChar[0]));

        infile.read(elemLengthChar, 4);
        int lengthOfElm = int((unsigned char)(elemLengthChar[3]) << 24 | 
                              (unsigned char)(elemLengthChar[2]) << 16 |
                              (unsigned char)(elemLengthChar[1]) << 8 | 
                              (unsigned char)(elemLengthChar[0]));

        infile.read(nameOfElm, 8);

        descriptorIncrementOffset += 16;
        std::string ourElm(nameOfElm);
        
        if(lengthOfElm == 0 && ourElm.find("_START") != std::string::npos){
            Node* temp = construct(ourElm.substr(0, ourElm.find("_START")), nullptr, 0);
            root = treeStack.top();
            root->children.push_back(temp);
            treeStack.push(temp);
            //std::cout << "start: " << temp->nodeContentnam << std::endl;
            //glados

        }
        else if (ourElm.length() == 4 && ourElm.substr(0,1) == "E" && ourElm.substr(2,1)=="M"){
            root=treeStack.top();
            Node* temp = construct(ourElm, nullptr, 0);
            root->children.push_back(temp);
            root = temp;
            count = i+10;
            //std::cout
            //elmo
        }
        else if(lengthOfElm == 0 && ourElm.find("_END") != std::string::npos){
            treeStack.pop();
            root = treeStack.top();
            //std::cout << "start: " << root->nodeContentnam << std::endl;
        }
        else if (i <= count) { //enter E#M#
            //advance after read
            char* space = new char[lengthOfElm];
            infile.seekg(offsetOfElm, std::ios::beg);
            infile.read(space, lengthOfElm);

            //make node set root
            Node* temp = construct(ourElm, space, lengthOfElm);
            root->children.push_back(temp);

            //seekg
            infile.seekg(wad->DescriptorOffset + descriptorIncrementOffset, std::ios::beg);

            if (i == count) {
                root = treeStack.top();
            }
        }
        else {
            //read from file + move forward
            char* space = new char[lengthOfElm];
            infile.seekg(offsetOfElm, std::ios::beg);
            infile.read(space, lengthOfElm);
            //add node 
            Node* temp = construct(ourElm, space, lengthOfElm);
            //advance
            infile.seekg(wad->DescriptorOffset + descriptorIncrementOffset, std::ios::beg);
            root = treeStack.top();
            root->children.push_back(temp);
            
        }
    }

    infile.close();
    wad->root = treeStack.top();
    treeStack.pop();

    //printNaryTree(root);
    return wad;

}


Node* retrieve(const std::string &path, Node* root){
    
    bool exists = false;
    Node* loc = root;
    std::string currentPathComponent;
    std::istringstream str(path);

    std::getline(str,currentPathComponent,'/');

    while(std::getline(str,currentPathComponent,'/')){
        for(int x = 0; x < loc->children.size(); x++){
            std::string nodeNameChild = loc->children[x]->nodeContentnam;
            if (nodeNameChild == currentPathComponent){
                loc = loc->children[x];
                exists = true;
            }
        }
        if (!exists)
        {
            return nullptr;
        }
        exists = false;
    }
    //std::cout << "hi" << std::endl;
    return loc;
}

Node* construct(std::string _nodeContentnam, char* _info, int _nodeContentLength){
    Node* temp = new Node();
    temp->nodeContentnam = _nodeContentnam;
    temp->info = _info;
    temp->nodeContentLength = _nodeContentLength;   

    //std::cout << "getEm" << std::endl;
    return temp;
}


/*Returns the magic for this WAD data.*/
std::string Wad::getMagic(){
    //std::cout << "magic" << std::endl;
    return magic;
}

/*Returns true if path represents content (data), and false otherwise.*/
bool Wad::isContent(const std::string &path) {
    
    Node* loc = root;
    std::string line;
    bool exist = false;
    std::istringstream pathString(path);
    getline(pathString, line, '/'); //ignore starting delimiter

    //sift through the words amd inputs to locate the delimiter
    while (getline(pathString, line, '/')) {
        for (int i = 0; i < loc->children.size(); i++) {
            std::string getName = loc->children[i]->nodeContentnam;
            if (getName == line) {
                //move temp down to this folder
                loc = loc->children[i];
                exist = true;
            }
        }

        // directory not exist
        if (!exist) {
            return false;
        }

        //sift again
        exist = false;
    }

    // We are at a file - ensure not dir
    if (loc->info != nullptr && loc->children.empty()) {
        return true;
    }
    else 
    {
        return false;
    }
}

/*Returns true if path represents a directory, and false otherwise.*/
bool Wad::isDirectory(const std::string &path) {
    Node* loc = root;
    std::string str;
    bool found = false;
    std::istringstream pathString(path);
    getline(pathString, str, '/'); //ignore starting delimiter

    //sift through the words amd inputs to locate the delimiter
    while (getline(pathString, str, '/')) {
        for (int i = 0; i < loc->children.size(); i++) {
            std::string getName = loc->children[i]->nodeContentnam;
            if (getName == str) {
                //move temp down to this folder
                loc = loc->children[i];
                found = true;
            }
        }

        // directory not exist
        if (!found) {
            return false;
        }

        //sift again
        found = false;
    }

    // We are at a file - ensure not dir
    if (loc->info == nullptr && !loc->children.empty()) {
        return true;
    }
    else 
    {
        return false;
    }
}

/*If path represents content, returns the number of bytes in its data; otherwise, returns -1.*/
int Wad::getSize(const std::string &path){
    if(this->isContent(path)){
        //std::cout << "getSize" << std::endl;
        return retrieve(path, root)->nodeContentLength;
    }
    //std::cout << "getSize" << std::endl;
    return -1;
}

/*If path represents a directory, places entries for immediately contained elements in directory. The elements
should be placed in the directory in the same order as they are found in the WAD file. Returns the number of
elements in the directory, or -1 if path does not represent a directory (e.g., if it represents content)
  // https://engineering.facile.it/blog/eng/write-filesystem-fuse/
  // https://engineering.facile.it/blog/eng/write-filesystem-fuse/
*/
int Wad::getDirectory(const std::string &path, std::vector<std::string> *directory){
    if(this->isDirectory(path)){
        for (auto & i : retrieve(path, this->root)->children)
            (*directory).push_back(i->nodeContentnam);

        //std::cout << "getDir" << std::endl;
        return retrieve(path, this->root)->children.size();
    }
    //std::cout << "getDir" << std::endl;
    return -1;
}

/*If path represents content, copies as many bytes as are available, up to length, of content's data into the preexisting buffer. If offset is provided, data should be copied starting from that byte in the content. Returns
number of bytes copied into buffer, or -1 if path does not represent content (e.g., if it represents a directory).*/
int Wad::getContents(const std::string &path, char *buffer, int length, int offset){
    if(this->isContent(path))
    {
        if(retrieve(path, root)->nodeContentLength - this->DescriptorOffset < length)
            length = retrieve(path, root)->nodeContentLength - offset;
        
        char* ans = retrieve(path, this->root)->info;
        std::memcpy(buffer, ans+offset, length);
        //std::cout << "getContent" << std::endl;
        return length;
    }
    //std::cout << "getContent" << std::endl;
    return -1;
}