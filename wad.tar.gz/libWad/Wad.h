#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
// Node declaration
struct Node{
   char* info;
   std::string nodeContentnam;
   int nodeContentLength = 0;

   std::vector<Node*> children;
};

Node* retrieve(Node* root, const std::string &path);
Node* construct(std::string nodeContentnam, char* data, int nodeContentLength);

class Wad{

public:
    Node* root = nullptr;
    std::string magic = "";
    int numbDescriptors = 0;
    int DescriptorOffset = 0;

    /*Object allocator; dynamically creates a Wad object and loads the WAD file data from path into memory.
    Caller must deallocate the memory using the delete keyword.*/
    static Wad* loadWad(const std::string &path);

    /*Returns the magic for this WAD data.*/
    std::string getMagic();

    /*Returns true if path represents content (data), and false otherwise.*/
    bool isContent(const std::string &path);

    /*Returns true if path represents a directory, and false otherwise.*/
    bool isDirectory(const std::string &path);

    /*If path represents content, returns the number of bytes in its data; otherwise, returns -1.*/
    int getSize(const std::string &path);

    /*If path represents a directory, places entries for immediately contained elements in directory. The elements
    should be placed in the directory in the same order as they are found in the WAD file. Returns the number of
    elements in the directory, or -1 if path does not represent a directory (e.g., if it represents content)*/
    int getDirectory(const std::string &path, std::vector<std::string> *directory);

    /*If path represents content, copies as many bytes as are available, up to length, of content's data into the preexisting buffer. If offset is provided, data should be copied starting from that byte in the content. Returns
    number of bytes copied into buffer, or -1 if path does not represent content (e.g., if it represents a directory).*/
    int getContents(const std::string &path, char *buffer, int length, int offset = 0);

    //Node* temp = create(_elem.substr(0, _elem.find("_START")), nullptr, 0);
};